#!/bin/bash
# ============================================
# N3 野良ファイル移動スクリプト
# ============================================
# 生成日時: 2025-01-30
# 検出された野良ファイル/ディレクトリ: 8件
#
# 3層構造ルール:
#   01_PRODUCT - 本番コード（クリーン）
#   02_DEV_LAB - 開発ファイル（すべて）
#   03_VAULT   - アーカイブ（古いファイル）
#
# ルートに許可されるファイル:
#   .env*, next.config.*, package*.json, tsconfig.json,
#   middleware.ts, tailwind.config.ts, README.md 等
# ============================================

set -e

PROJECT_ROOT="${1:-$(pwd)}"

echo ''
echo '============================================'
echo 'N3 野良ファイル移動スクリプト'
echo '============================================'
echo "プロジェクトルート: $PROJECT_ROOT"
echo ''

# 確認
read -p "移動を実行しますか？ (y/N): " confirm
if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
    echo "キャンセルしました"
    exit 0
fi

echo ''
echo '移動を開始します...'
echo ''

# ============================================
# 1. 野良ファイル（ルートレベル）
# ============================================

# 1-1. ドキュメント類 → 02_DEV_LAB/docs/
echo '📄 ドキュメントファイルを移動中...'

mkdir -p "$PROJECT_ROOT/02_DEV_LAB/docs/blueprints"
mkdir -p "$PROJECT_ROOT/02_DEV_LAB/docs/instructions"

if [ -f "$PROJECT_ROOT/BLUEPRINT_ERROR_HANDOVER.md" ]; then
    mv "$PROJECT_ROOT/BLUEPRINT_ERROR_HANDOVER.md" "$PROJECT_ROOT/02_DEV_LAB/docs/blueprints/"
    echo "  ✅ BLUEPRINT_ERROR_HANDOVER.md → 02_DEV_LAB/docs/blueprints/"
fi

if [ -f "$PROJECT_ROOT/FINAL_MASTER_INSTRUCTION.md" ]; then
    mv "$PROJECT_ROOT/FINAL_MASTER_INSTRUCTION.md" "$PROJECT_ROOT/02_DEV_LAB/docs/instructions/"
    echo "  ✅ FINAL_MASTER_INSTRUCTION.md → 02_DEV_LAB/docs/instructions/"
fi

# 1-2. Python スクリプト → 02_DEV_LAB/python-scripts/
echo '🐍 Pythonスクリプトを移動中...'

mkdir -p "$PROJECT_ROOT/02_DEV_LAB/python-scripts"

if [ -f "$PROJECT_ROOT/import_yahoo.py" ]; then
    mv "$PROJECT_ROOT/import_yahoo.py" "$PROJECT_ROOT/02_DEV_LAB/python-scripts/"
    echo "  ✅ import_yahoo.py → 02_DEV_LAB/python-scripts/"
fi

if [ -f "$PROJECT_ROOT/migrate_brain.py" ]; then
    mv "$PROJECT_ROOT/migrate_brain.py" "$PROJECT_ROOT/02_DEV_LAB/python-scripts/"
    echo "  ✅ migrate_brain.py → 02_DEV_LAB/python-scripts/"
fi

# 1-3. シェルスクリプト → 02_DEV_LAB/scripts/
echo '📜 シェルスクリプトを移動中...'

mkdir -p "$PROJECT_ROOT/02_DEV_LAB/scripts"

if [ -f "$PROJECT_ROOT/sync-to-product.sh" ]; then
    mv "$PROJECT_ROOT/sync-to-product.sh" "$PROJECT_ROOT/02_DEV_LAB/scripts/"
    echo "  ✅ sync-to-product.sh → 02_DEV_LAB/scripts/"
fi

# 1-4. CSVファイル → 02_DEV_LAB/data/csv/
echo '📊 CSVファイルを移動中...'

mkdir -p "$PROJECT_ROOT/02_DEV_LAB/data/csv"

if [ -f "$PROJECT_ROOT/Supabase Snippet code_map table size and row count.csv" ]; then
    mv "$PROJECT_ROOT/Supabase Snippet code_map table size and row count.csv" "$PROJECT_ROOT/02_DEV_LAB/data/csv/"
    echo "  ✅ Supabase Snippet...csv → 02_DEV_LAB/data/csv/"
fi

# 1-5. アーカイブファイル → 03_VAULT/_archives/
echo '📦 アーカイブファイルを移動中...'

mkdir -p "$PROJECT_ROOT/03_VAULT/_archives"

if [ -f "$PROJECT_ROOT/02_DEV_LAB.zip" ]; then
    mv "$PROJECT_ROOT/02_DEV_LAB.zip" "$PROJECT_ROOT/03_VAULT/_archives/"
    echo "  ✅ 02_DEV_LAB.zip → 03_VAULT/_archives/"
fi

# ============================================
# 2. 野良ディレクトリ（ルートレベル）
# ============================================

# 2-1. バックアップディレクトリ → 03_VAULT/
echo '📁 バックアップディレクトリを移動中...'

if [ -d "$PROJECT_ROOT/web-app-backup-20260122_115511" ]; then
    mv "$PROJECT_ROOT/web-app-backup-20260122_115511" "$PROJECT_ROOT/03_VAULT/"
    echo "  ✅ web-app-backup-20260122_115511 → 03_VAULT/"
fi

# ============================================
# 3. 空のファイルをクリーンアップ
# ============================================
echo '🧹 空のファイルをチェック中...'

if [ -f "$PROJECT_ROOT/next.config.mjs" ]; then
    size=$(stat -f%z "$PROJECT_ROOT/next.config.mjs" 2>/dev/null || stat -c%s "$PROJECT_ROOT/next.config.mjs" 2>/dev/null)
    if [ "$size" = "0" ]; then
        rm "$PROJECT_ROOT/next.config.mjs"
        echo "  ✅ 空ファイル削除: next.config.mjs (0バイト)"
    fi
fi

# ============================================
# 完了レポート
# ============================================
echo ''
echo '============================================'
echo '移動完了'
echo '============================================'
echo ''
echo '移動先サマリー:'
echo '  - 02_DEV_LAB/docs/blueprints/: ブループリントドキュメント'
echo '  - 02_DEV_LAB/docs/instructions/: 指示書'
echo '  - 02_DEV_LAB/python-scripts/: Pythonスクリプト'
echo '  - 02_DEV_LAB/scripts/: シェルスクリプト'
echo '  - 02_DEV_LAB/data/csv/: CSVデータ'
echo '  - 03_VAULT/_archives/: アーカイブ'
echo '  - 03_VAULT/: バックアップディレクトリ'
echo ''
echo '✅ 野良ファイルの整理が完了しました'
