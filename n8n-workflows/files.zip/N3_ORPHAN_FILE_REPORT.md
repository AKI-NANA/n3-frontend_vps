# N3 野良ファイル検出レポート
## 生成日時: 2025-01-30

---

## 📋 概要

N3プロジェクトの3層構造ルールに基づき、ルートディレクトリをスキャンしました。

### 3層構造ルール
| レイヤー | ディレクトリ | 用途 |
|---------|-------------|------|
| 本番 | `01_PRODUCT` | クリーンな本番コードのみ |
| 開発 | `02_DEV_LAB` | 開発中のすべてのファイル |
| 保管 | `03_VAULT` | アーカイブ・バックアップ |

### ルートに許可されるファイル
- 環境設定: `.env`, `.env.local`, `.env.development`
- Next.js設定: `next.config.ts`, `next-env.d.ts`
- パッケージ: `package.json`, `package-lock.json`
- TypeScript: `tsconfig.json`
- スタイル: `tailwind.config.ts`, `postcss.config.mjs`
- その他: `middleware.ts`, `components.json`, `README.md`

---

## 🔴 検出された野良ファイル

### 📄 ドキュメント類 (2件)

| ファイル名 | サイズ | 移動先 |
|-----------|--------|--------|
| `BLUEPRINT_ERROR_HANDOVER.md` | 20.50 KB | `02_DEV_LAB/docs/blueprints/` |
| `FINAL_MASTER_INSTRUCTION.md` | 12.83 KB | `02_DEV_LAB/docs/instructions/` |

**理由**: ドキュメントファイルはルートに置かず、`02_DEV_LAB/docs/` 以下で整理すべき。

---

### 🐍 Python スクリプト (2件)

| ファイル名 | サイズ | 移動先 |
|-----------|--------|--------|
| `import_yahoo.py` | 1.22 KB | `02_DEV_LAB/python-scripts/` |
| `migrate_brain.py` | 727 B | `02_DEV_LAB/python-scripts/` |

**理由**: Pythonスクリプトは `scripts/` または `02_DEV_LAB/python-scripts/` で管理すべき。

---

### 📜 シェルスクリプト (1件)

| ファイル名 | サイズ | 移動先 |
|-----------|--------|--------|
| `sync-to-product.sh` | 7.12 KB | `02_DEV_LAB/scripts/` |

**理由**: シェルスクリプトは `scripts/` または `02_DEV_LAB/scripts/` で管理すべき。

---

### 📊 データファイル (1件)

| ファイル名 | サイズ | 移動先 |
|-----------|--------|--------|
| `Supabase Snippet code_map table size and row count.csv` | 474.61 KB | `02_DEV_LAB/data/csv/` |

**理由**: CSVファイルは `02_DEV_LAB/data/csv/` で管理すべき。

---

### 📦 アーカイブファイル (1件)

| ファイル名 | サイズ | 移動先 |
|-----------|--------|--------|
| `02_DEV_LAB.zip` | 429.70 MB | `03_VAULT/_archives/` |

**理由**: アーカイブファイルは `03_VAULT/_archives/` に保管すべき。

---

## 🔵 検出された野良ディレクトリ

### 📁 バックアップディレクトリ (1件)

| ディレクトリ名 | 移動先 |
|---------------|--------|
| `web-app-backup-20260122_115511` | `03_VAULT/` |

**理由**: バックアップディレクトリは `03_VAULT/` に保管すべき。

---

## ⚠️ 注意事項

### 空ファイル
| ファイル名 | サイズ | 対応 |
|-----------|--------|------|
| `next.config.mjs` | 0 B | 削除推奨（`next.config.ts` が存在するため） |

---

## 📈 サマリー

| 種別 | 件数 | 合計サイズ |
|------|------|-----------|
| 野良ファイル | 7件 | 430.24 MB |
| 野良ディレクトリ | 1件 | - |
| **合計** | **8件** | - |

---

## ✅ 適正なルートレベルの確認

現在ルートに存在し、**適正な**ファイル/ディレクトリ:

### ファイル ✅
- `.DS_Store` (システムファイル)
- `.env` (環境設定)
- `.env.local` (ローカル環境設定)
- `middleware.ts` (Next.js必須)
- `next-env.d.ts` (Next.js生成)
- `next.config.ts` (Next.js設定)
- `package.json` (パッケージ定義)
- `package-lock.json` (パッケージロック)
- `tailwind.config.ts` (Tailwind設定)
- `tsconfig.json` (TypeScript設定)

### ディレクトリ ✅
- `01_PRODUCT` (本番コード)
- `02_DEV_LAB` (開発ファイル)
- `03_VAULT` (アーカイブ)
- `app` (Next.js App Router)
- `components` (UIコンポーネント)
- `config` (設定)
- `contexts` (Reactコンテキスト)
- `docs` (ドキュメント)
- `hooks` (カスタムフック)
- `layouts` (レイアウト)
- `lib` (ライブラリ)
- `migrations` (DBマイグレーション)
- `node_modules` (依存パッケージ)
- `public` (静的ファイル)
- `remotion` (動画生成)
- `scripts` (スクリプト)
- `services` (サービス層)
- `store` (状態管理)
- `types` (型定義)
- `mcp-servers` (MCP設定)
- `yoga` (関連プロジェクト)
- `.mcp-venv` (Python仮想環境)
- `.next` (Next.jsビルド)

---

## 🚀 実行手順

### 方法1: 移動スクリプトを使用

```bash
cd ~/n3-frontend_new
bash move_n3_orphans.sh .
```

### 方法2: 手動で移動

```bash
cd ~/n3-frontend_new

# ドキュメント
mkdir -p 02_DEV_LAB/docs/{blueprints,instructions}
mv BLUEPRINT_ERROR_HANDOVER.md 02_DEV_LAB/docs/blueprints/
mv FINAL_MASTER_INSTRUCTION.md 02_DEV_LAB/docs/instructions/

# Python
mkdir -p 02_DEV_LAB/python-scripts
mv import_yahoo.py migrate_brain.py 02_DEV_LAB/python-scripts/

# シェルスクリプト
mkdir -p 02_DEV_LAB/scripts
mv sync-to-product.sh 02_DEV_LAB/scripts/

# CSV
mkdir -p 02_DEV_LAB/data/csv
mv "Supabase Snippet code_map table size and row count.csv" 02_DEV_LAB/data/csv/

# アーカイブ
mkdir -p 03_VAULT/_archives
mv 02_DEV_LAB.zip 03_VAULT/_archives/

# バックアップディレクトリ
mv web-app-backup-20260122_115511 03_VAULT/

# 空ファイル削除
rm -f next.config.mjs
```

---

## 📝 整理後のルートディレクトリ構造

```
n3-frontend_new/
├── .env
├── .env.local
├── .mcp-venv/
├── .next/
├── 01_PRODUCT/         ← 本番コード
├── 02_DEV_LAB/         ← 開発ファイル
│   ├── docs/
│   │   ├── blueprints/
│   │   └── instructions/
│   ├── python-scripts/
│   ├── scripts/
│   └── data/
│       └── csv/
├── 03_VAULT/           ← アーカイブ
│   ├── _archives/
│   └── web-app-backup-.../
├── app/
├── components/
├── config/
├── contexts/
├── docs/
├── hooks/
├── layouts/
├── lib/
├── mcp-servers/
├── middleware.ts
├── migrations/
├── next-env.d.ts
├── next.config.ts
├── node_modules/
├── package-lock.json
├── package.json
├── public/
├── remotion/
├── scripts/
├── services/
├── store/
├── tailwind.config.ts
├── tsconfig.json
├── types/
└── yoga/
```

---

## 🔄 今後のルール（野良ファイル防止）

1. **新規ドキュメント**: `02_DEV_LAB/docs/` に作成
2. **新規スクリプト**: `02_DEV_LAB/scripts/` または `02_DEV_LAB/python-scripts/`
3. **データファイル**: `02_DEV_LAB/data/` に保存
4. **バックアップ**: `03_VAULT/` に保存
5. **アーカイブ(.zip等)**: `03_VAULT/_archives/` に保存

---

*レポート生成: N3 Orphan Scanner v1.0*
