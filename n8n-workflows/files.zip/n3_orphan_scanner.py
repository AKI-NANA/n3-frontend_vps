#!/usr/bin/env python3
"""
N3 野良ファイル検出・移動スクリプト
=====================================

N3プロジェクトの3層構造:
- 01_PRODUCT: 本番用コード（クリーン）
- 02_DEV_LAB: 開発用（すべてのファイル）
- 03_VAULT: アーカイブ（古いファイル）

ルール:
1. ルートに置いて良いのは: .env*, next.config.*, package*.json, tsconfig.json, 
   middleware.ts, tailwind.config.ts, postcss.config.*, eslint.config.mjs のみ
2. Next.js標準ディレクトリ (app, components, lib等) はルートに存在するが、
   実際の開発作業は 02_DEV_LAB 内で行う
3. ドキュメント類(.md)はルートに置かない → 02_DEV_LAB/docs/ または 03_VAULT/_docs_archive/
4. バックアップ系ディレクトリ (*backup*, *archive*等) → 03_VAULT/
5. 画像ファイル(.png, .jpg等) → 02_DEV_LAB/data/ または 03_VAULT/
6. SQLファイル → migrations/ または 03_VAULT/sql/
7. Pythonスクリプト → scripts/ または 02_DEV_LAB/python-scripts/
8. .zip等のアーカイブファイル → 03_VAULT/_archives/
"""

import os
import sys
import shutil
import json
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Tuple, Optional

# ============================================
# 設定
# ============================================

# N3プロジェクトの3層構造
TIERS = {
    "PRODUCTION": "01_PRODUCT",
    "DEVELOPMENT": "02_DEV_LAB", 
    "ARCHIVE": "03_VAULT"
}

# ルートに存在を許可するファイル（正規表現パターン）
ALLOWED_ROOT_FILES = {
    # 環境設定
    ".env",
    ".env.local",
    ".env.development",
    ".env.production",
    ".env.example",
    # Next.js設定
    "next.config.ts",
    "next.config.mjs",
    "next.config.js",
    "next-env.d.ts",
    # パッケージ管理
    "package.json",
    "package-lock.json",
    # TypeScript設定
    "tsconfig.json",
    # スタイル設定
    "tailwind.config.ts",
    "tailwind.config.js",
    "postcss.config.mjs",
    "postcss.config.js",
    # コード品質
    "eslint.config.mjs",
    ".eslintrc.json",
    ".prettierrc",
    # その他必須
    "middleware.ts",
    "components.json",
    # Git
    ".gitignore",
    ".gitattributes",
    # その他システム
    ".DS_Store",
    "README.md",
}

# ルートに存在を許可するディレクトリ
ALLOWED_ROOT_DIRS = {
    # 3層構造
    "01_PRODUCT",
    "02_DEV_LAB",
    "03_VAULT",
    # Next.js標準（ルートに必要）
    "app",
    "components",
    "lib",
    "public",
    "hooks",
    "contexts",
    "layouts",
    "store",
    "types",
    "services",
    "config",
    # 開発関連
    "node_modules",
    ".next",
    ".git",
    ".mcp-venv",
    "mcp-servers",
    # その他（検討中）
    "scripts",
    "migrations",
    "docs",
    "remotion",
    "yoga",
}

# ファイル種別ごとの移動先マッピング
FILE_TYPE_MAPPING = {
    # ドキュメント類
    ".md": {
        "keywords": {
            "HANDOVER": "02_DEV_LAB/docs/handover/",
            "INSTRUCTION": "02_DEV_LAB/docs/instructions/",
            "BLUEPRINT": "02_DEV_LAB/docs/blueprints/",
            "ERROR": "02_DEV_LAB/docs/errors/",
            "REPORT": "02_DEV_LAB/docs/reports/",
            "GUIDE": "02_DEV_LAB/docs/guides/",
            "MANUAL": "02_DEV_LAB/docs/manuals/",
            "SUMMARY": "02_DEV_LAB/docs/summaries/",
            "CHAT_SESSION": "02_DEV_LAB/docs/sessions/",
        },
        "default": "02_DEV_LAB/docs/"
    },
    # SQL
    ".sql": {
        "default": "02_DEV_LAB/database/migrations/"
    },
    # Python
    ".py": {
        "default": "02_DEV_LAB/python-scripts/"
    },
    # シェルスクリプト
    ".sh": {
        "default": "02_DEV_LAB/scripts/"
    },
    # アーカイブ
    ".zip": {
        "default": "03_VAULT/_archives/"
    },
    ".tar.gz": {
        "default": "03_VAULT/_archives/"
    },
    ".7z": {
        "default": "03_VAULT/_archives/"
    },
    # 画像
    ".png": {
        "default": "02_DEV_LAB/data/images/"
    },
    ".jpg": {
        "default": "02_DEV_LAB/data/images/"
    },
    ".jpeg": {
        "default": "02_DEV_LAB/data/images/"
    },
    ".gif": {
        "default": "02_DEV_LAB/data/images/"
    },
    ".svg": {
        "default": "02_DEV_LAB/data/images/"
    },
    # CSV/データ
    ".csv": {
        "default": "02_DEV_LAB/data/csv/"
    },
    ".json": {
        "keywords": {
            "backup": "03_VAULT/_backup/",
        },
        "default": "02_DEV_LAB/json/"
    },
}

# ディレクトリ種別ごとの移動先マッピング
DIR_TYPE_MAPPING = {
    "backup": "03_VAULT/_backup/",
    "archive": "03_VAULT/_archives/",
    "old": "03_VAULT/",
    "legacy": "03_VAULT/",
    "duplicate": "03_VAULT/",
    "-old": "03_VAULT/",
    "_old": "03_VAULT/",
}


class OrphanScanner:
    """N3プロジェクトの野良ファイルスキャナー"""
    
    def __init__(self, project_root: str, dry_run: bool = True):
        self.project_root = Path(project_root)
        self.dry_run = dry_run
        self.orphans: List[Dict] = []
        self.scan_time = datetime.now().strftime("%Y%m%d_%H%M%S")
        
    def scan(self) -> List[Dict]:
        """ルートディレクトリをスキャンして野良ファイルを検出"""
        print(f"\n{'='*60}")
        print(f"N3 野良ファイルスキャナー")
        print(f"{'='*60}")
        print(f"プロジェクトルート: {self.project_root}")
        print(f"モード: {'ドライラン（移動しない）' if self.dry_run else '実行モード'}")
        print(f"{'='*60}\n")
        
        for item in self.project_root.iterdir():
            if item.name.startswith('.') and item.name not in ALLOWED_ROOT_FILES:
                # 隠しファイル/ディレクトリ（許可リスト以外）
                if item.is_file():
                    self._add_orphan(item, "hidden_file")
            elif item.is_file():
                self._check_file(item)
            elif item.is_dir():
                self._check_directory(item)
                
        return self.orphans
    
    def _check_file(self, file_path: Path):
        """ファイルをチェック"""
        if file_path.name in ALLOWED_ROOT_FILES:
            return
            
        # 拡張子を取得
        ext = file_path.suffix.lower()
        
        # 移動先を決定
        dest = self._get_destination_for_file(file_path, ext)
        
        self._add_orphan(file_path, "orphan_file", dest)
        
    def _check_directory(self, dir_path: Path):
        """ディレクトリをチェック"""
        if dir_path.name in ALLOWED_ROOT_DIRS:
            return
            
        # 野良ディレクトリの種類を判定
        dir_name_lower = dir_path.name.lower()
        
        for keyword, dest in DIR_TYPE_MAPPING.items():
            if keyword in dir_name_lower:
                self._add_orphan(dir_path, "orphan_dir", dest)
                return
                
        # その他の野良ディレクトリ
        self._add_orphan(dir_path, "orphan_dir", "03_VAULT/")
        
    def _get_destination_for_file(self, file_path: Path, ext: str) -> str:
        """ファイルの移動先を決定"""
        if ext in FILE_TYPE_MAPPING:
            mapping = FILE_TYPE_MAPPING[ext]
            
            # キーワードマッチング
            if "keywords" in mapping:
                name_upper = file_path.name.upper()
                for keyword, dest in mapping["keywords"].items():
                    if keyword.upper() in name_upper:
                        return dest
                        
            return mapping["default"]
            
        # 未知の拡張子
        return "02_DEV_LAB/misc/"
        
    def _add_orphan(self, path: Path, orphan_type: str, destination: str = None):
        """野良ファイル/ディレクトリを追加"""
        self.orphans.append({
            "path": str(path),
            "name": path.name,
            "type": orphan_type,
            "is_dir": path.is_dir(),
            "destination": destination,
            "size": self._get_size(path),
        })
        
    def _get_size(self, path: Path) -> int:
        """ファイル/ディレクトリのサイズを取得"""
        if path.is_file():
            return path.stat().st_size
        elif path.is_dir():
            total = 0
            for item in path.rglob('*'):
                if item.is_file():
                    total += item.stat().st_size
            return total
        return 0
        
    def print_report(self):
        """レポートを出力"""
        if not self.orphans:
            print("✅ 野良ファイル/ディレクトリは見つかりませんでした。")
            return
            
        print(f"\n{'='*60}")
        print(f"検出された野良ファイル/ディレクトリ: {len(self.orphans)}件")
        print(f"{'='*60}\n")
        
        # カテゴリ別に分類
        files = [o for o in self.orphans if not o["is_dir"]]
        dirs = [o for o in self.orphans if o["is_dir"]]
        
        if files:
            print("📄 野良ファイル:")
            print("-" * 50)
            for f in files:
                size_str = self._format_size(f["size"])
                print(f"  {f['name']} ({size_str})")
                print(f"    → 移動先: {f['destination']}")
            print()
            
        if dirs:
            print("📁 野良ディレクトリ:")
            print("-" * 50)
            for d in dirs:
                size_str = self._format_size(d["size"])
                print(f"  {d['name']}/ ({size_str})")
                print(f"    → 移動先: {d['destination']}")
            print()
            
    def _format_size(self, size: int) -> str:
        """サイズを人間が読みやすい形式に変換"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024:
                return f"{size:.2f} {unit}"
            size /= 1024
        return f"{size:.2f} TB"
        
    def move_orphans(self) -> List[Dict]:
        """野良ファイルを移動"""
        results = []
        
        for orphan in self.orphans:
            if orphan["destination"]:
                source = Path(orphan["path"])
                dest_dir = self.project_root / orphan["destination"]
                dest = dest_dir / orphan["name"]
                
                if self.dry_run:
                    results.append({
                        "action": "would_move",
                        "source": str(source),
                        "destination": str(dest),
                        "status": "dry_run"
                    })
                else:
                    try:
                        # 移動先ディレクトリを作成
                        dest_dir.mkdir(parents=True, exist_ok=True)
                        
                        # 同名ファイルが存在する場合はリネーム
                        if dest.exists():
                            base = dest.stem
                            suffix = dest.suffix
                            counter = 1
                            while dest.exists():
                                dest = dest_dir / f"{base}_{counter}{suffix}"
                                counter += 1
                        
                        # 移動
                        shutil.move(str(source), str(dest))
                        
                        results.append({
                            "action": "moved",
                            "source": str(source),
                            "destination": str(dest),
                            "status": "success"
                        })
                    except Exception as e:
                        results.append({
                            "action": "move_failed",
                            "source": str(source),
                            "destination": str(dest),
                            "status": "error",
                            "error": str(e)
                        })
                        
        return results
        
    def generate_migration_script(self) -> str:
        """移動用のシェルスクリプトを生成"""
        script_lines = [
            "#!/bin/bash",
            f"# N3 野良ファイル移動スクリプト",
            f"# 生成日時: {self.scan_time}",
            f"# 野良ファイル数: {len(self.orphans)}",
            "",
            'set -e',
            "",
            f'PROJECT_ROOT="{self.project_root}"',
            "",
            "echo '======================================'",
            "echo 'N3 野良ファイル移動スクリプト'",
            "echo '======================================'",
            "",
        ]
        
        for i, orphan in enumerate(self.orphans, 1):
            if orphan["destination"]:
                source = Path(orphan["path"]).name
                dest_dir = orphan["destination"]
                
                script_lines.extend([
                    f"# {i}. {source}",
                    f'mkdir -p "$PROJECT_ROOT/{dest_dir}"',
                    f'if [ -e "$PROJECT_ROOT/{source}" ]; then',
                    f'    mv "$PROJECT_ROOT/{source}" "$PROJECT_ROOT/{dest_dir}"',
                    f'    echo "✅ 移動完了: {source} → {dest_dir}"',
                    f'else',
                    f'    echo "⚠️  スキップ: {source} (存在しない)"',
                    f'fi',
                    "",
                ])
                
        script_lines.extend([
            "echo ''",
            "echo '======================================'",
            "echo '移動完了'",
            "echo '======================================'",
        ])
        
        return "\n".join(script_lines)


def main():
    """メイン関数"""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="N3プロジェクトの野良ファイルを検出・移動"
    )
    parser.add_argument(
        "project_root",
        help="N3プロジェクトのルートディレクトリ"
    )
    parser.add_argument(
        "--execute",
        action="store_true",
        help="実際に移動を実行（デフォルトはドライラン）"
    )
    parser.add_argument(
        "--script",
        action="store_true",
        help="移動用シェルスクリプトを生成"
    )
    parser.add_argument(
        "--output",
        help="スクリプト出力先ファイル名"
    )
    
    args = parser.parse_args()
    
    scanner = OrphanScanner(args.project_root, dry_run=not args.execute)
    scanner.scan()
    scanner.print_report()
    
    if args.script:
        script = scanner.generate_migration_script()
        if args.output:
            with open(args.output, 'w') as f:
                f.write(script)
            print(f"\n📝 スクリプトを保存: {args.output}")
        else:
            print("\n" + "="*60)
            print("移動用シェルスクリプト")
            print("="*60)
            print(script)
            
    if args.execute:
        print("\n🚀 移動を実行中...")
        results = scanner.move_orphans()
        
        success = [r for r in results if r["status"] == "success"]
        failed = [r for r in results if r["status"] == "error"]
        
        print(f"\n✅ 成功: {len(success)}件")
        if failed:
            print(f"❌ 失敗: {len(failed)}件")
            for f in failed:
                print(f"  - {f['source']}: {f['error']}")
    else:
        if scanner.orphans:
            print("\n💡 実際に移動するには --execute オプションを付けて実行してください")
            print("💡 シェルスクリプトを生成するには --script オプションを使用")


if __name__ == "__main__":
    main()
